# Superstore Dirty Dataset — Answer Key

Original: `superstore_dataset2011-2015.csv` (51,290 rows)
Dirty version: `superstore_dirty.csv` (51,525 rows)

Don't peek until you've had a go at cleaning it — use this to check your work after.

## Issues injected

1. **Missing values, inconsistent markers** — blanks mixed with `N/A`, `NULL`, `null`, `Unknown`, `-`, `?`, `n/a`, `NaN`, `None` in: Customer Name, Segment, City, State, Ship Mode, Order Priority, Sub-Category, Discount, Shipping Cost.
2. **Inconsistent date formats** — `Order Date` / `Ship Date` mix `M/D/YYYY`, `DD-MM-YYYY`, `YYYY-MM-DD`, and text like `Apr 10, 2013`. A few rows have an impossible date (`13/45/2013`) and a few have `Ship Date` set to `1/1/1900` (before the order date — logical error).
3. **Inconsistent casing/whitespace** — Segment, Ship Mode, Category, Order Priority randomly upper/lowercased; leading/trailing spaces added to Customer Name, City, State, Country, Product Name.
4. **Typos** in Category (`Office Suplies`, `Furnture`, `Tecnology`, etc.) and Sub-Category (`Storrage`, `Chiars`, `Phonez`, etc.).
5. **Currency-formatted numbers stored as strings** — some Sales/Profit/Shipping Cost values have `$` and thousands-comma separators, breaking numeric dtype.
6. **Bad Quantity values** — a few negative quantities, a few literal text values (`"two"`).
7. **Discount range errors** — a few discounts multiplied by 100 (e.g. `0.2` → `20`), so they're out of the expected 0–1 range.
8. **Inconsistent Country naming** — `United States` sometimes appears as `USA`, `US`, `U.S.A.`, `United States of America`; `United Kingdom` as `UK`, `U.K.`, `Great Britain`.
9. **Inconsistent Order Priority labels** — `Medium`/`Med`/`MEDIUM`, `High`/`Hi`/`HIGH`, etc.
10. **Mojibake / encoding glitches** — accented characters (é, ü, ñ, ö, è) in Customer Name, City, Product Name sometimes appear as garbled UTF-8-as-Latin-1 sequences (e.g. `Ã©`).
11. **Postal Code mess** — mostly missing (as in the original), plus some explicit `N/A` strings and some `00000` placeholders.
12. **Duplicate rows** — 150 exact duplicate rows, plus 80 near-duplicates (same record, Customer Name re-cased).
13. **Fully blank rows** — 5 rows where every field is null.
14. **Duplicate Row IDs** — ~40 rows where `Row ID` collides with another row's ID, breaking uniqueness assumptions.
15. Rows are shuffled, so dirty rows aren't clustered at the end.

## Suggested cleaning workflow
- Standardize missing-value markers → real `NaN`
- Parse and normalize dates (watch for the impossible date + ship-before-order logic check)
- Strip whitespace, normalize casing on categorical columns
- Fix typos via mapping/fuzzy matching on Category/Sub-Category
- Strip `$`/commas and cast Sales/Profit/Shipping Cost to float
- Validate Quantity (numeric, non-negative) and Discount (0–1 range)
- Standardize Country/Order Priority via mapping dictionaries
- Fix encoding issues (`.encode('latin1').decode('utf-8')` trick, or manual replace)
- Drop exact duplicates, investigate near-duplicates and duplicate Row IDs, drop fully-blank rows
